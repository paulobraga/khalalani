<?php
App::uses('AppModel', 'Model');
/**
 * MaritalStatus Model
 *
 */
class MaritalStatus extends AppModel {
    
    public $displayField='name';

}
